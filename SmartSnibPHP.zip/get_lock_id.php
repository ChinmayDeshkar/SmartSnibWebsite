<?php

    // $conn = mysqli_connect("localhost", "root", "", "smartysnib");
    $conn = mysqli_connect("localhost", "id17317334_admin", "Chinmay@1234", "id17317334_smartsnib");
    
    $sql = "SELECT Lock_ID FROM `lock_info`";
    $result = mysqli_query($conn, $sql);

    $data = array();
    while($a = mysqli_fetch_assoc($result)){
        array_push($data,$a['Lock_ID']);
    }

    echo json_encode($data);

?>