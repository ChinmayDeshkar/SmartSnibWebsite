<?php

    $conn = mysqli_connect("localhost", "id17317334_admin", "Chinmay@1234", "id17317334_smartsnib");
    if (!$conn) {
        echo "connection failed";
    }
 
 // Getting the received JSON into $json variable.
 $json = file_get_contents('php://input');
 
 // Decoding the received JSON and store into $obj variable.
 $obj = json_decode($json,true);
 
 // Getting User email from JSON $obj array and store into $email.
 $user = $obj['user'];
 
 // Getting Password from JSON $obj array and store into $password.
 $password = $obj['password'];
 
 $query = "SELECT `mobno` FROM user_login WHERE userID = '$user' and password = '$password'";

 $result = mysqli_fetch_assoc(mysqli_query($conn, $query));

 $mobno = $result['mobno'];

 $sendData = json_encode($mobno);

 echo $sendData;

 mysqli_close($conn);
 
 
?>