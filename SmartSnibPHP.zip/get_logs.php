<?php

    $conn = mysqli_connect("localhost", "id17317334_admin", "Chinmay@1234", "id17317334_smartsnib");

   // Getting the received JSON into $json variable.
	 $json = file_get_contents('php://input');
 
	 // Decoding the received JSON and store into $obj variable.
	 $obj = json_decode($json,true);
	 
	 // Getting User email from JSON $obj array and store into $email.
// 	 $Stt = $obj['status'];
	 
    $lock_id = $obj['id'];
    // echo $lock_id;
    // $lock_id = "lock_1";
    $logs_query = "SELECT Date, SUBSTRING(Time,1,5) as Time, accessby FROM `logs` WHERE lock_id = '".$lock_id."'  ORDER BY `logs`.`TimeStamp` DESC";
    $result = mysqli_query($conn, $logs_query);
    $logData = array();
    while($log = mysqli_fetch_assoc($result)){
        array_push($logData, $log);
    }
    echo json_encode($logData);
    // $send = json_encode($lock_id);
    // echo $send;

?>