<?php
	

$server 	= "localhost";	// Change this to correspond with your database port
$username 	= "id17317334_admin";			// Change if use webhost online
$password 	= "Chinmay@1234";
$DB 		= "id17317334_smartsnib";		// database name

$conn = mysqli_connect($server,$username,$password,$DB);
if (!$conn) {
    echo "Connection Error...";
}
    // Getting the received JSON into $json variable.
     $json = file_get_contents('php://input');
     
     // Decoding the received JSON and store into $obj variable.
     $obj = json_decode($json,true);
     
     // Getting User email from JSON $obj array and store into $email.
     $lock_id = $obj['lock_id'];
     
    $sql = "SELECT * FROM $lock_id ORDER BY `TimeStamp` DESC ";
    
        $result = mysqli_query($conn, $sql);
        $data = mysqli_fetch_assoc($result);
        
        $send_data = array($data['Temperature'], $data['Humidity']);
        
		 // Converting the message into JSON format.
		 $SuccessMSG = json_encode($send_data);
		 
		 // Echo the message.
		 echo $SuccessMSG ; 



?>