<?php

$server 	= "localhost";	// Change this to correspond with your database port
$username 	= "id17317334_admin";			// Change if use webhost online
$password 	= "Chinmay@1234";
$DB 		= "id17317334_smartsnib";			// database name

    // $Stt = $_POST["status"];

	 // Getting the received JSON into $json variable.
	 $json = file_get_contents('php://input');
 
	 // Decoding the received JSON and store into $obj variable.
	 $obj = json_decode($json,true);
	 
	 // Getting User email from JSON $obj array and store into $email.
	 $Stt = $obj['status'];
    // $Stt = 0;

	// Get data with variable is "status" sending from Android App 
    $update = new mysqli($server, $username, $password, $DB); // Check database connection
	     if ($update->connect_error) {
				die("Connection failed: " . $update->connect_error);
			} 
			
		$lock = $_GET['lock'];
// 		$lock= 3;
		if($lock == 1){
		    $sql = "UPDATE status SET status = ". $Stt;
		    if ($update->query($sql) === TRUE) {		// If don't put this If , we can't change the value in database
				echo "1";					
		    }echo "zdcx";
		}
		if($lock == 2){
		    $sql = "UPDATE status SET L2_status = ".$Stt;	// Update present status to status table	
			    if ($update->query($sql) === TRUE) {		// If don't put this If , we can't change the value in database
				echo "1";
			    }echo "zdcx";
		}
		if($lock == 3){
		    $sql = "UPDATE status SET L2_status = ".$Stt.", status = ".$Stt." Where 1;";	// Update present status to database
		     	if ($update->query($sql) === TRUE) {		// If don't put this If , we can't change the value in database
				echo "1";
	            }
				echo $sql;
		}
?>