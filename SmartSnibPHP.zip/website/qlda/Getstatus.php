<?php

 $servername = "localhost";	// Change this to correspond with your database port
    $username 	= "id17317334_admin";			// Change if use webhost online
    $password 	= "Chinmay@1234";
    $dbname 	= "id17317334_smartsnib";

    // Create connection
    $conn = new mysqli($servername, $username, $password, $dbname);
    // Check connection
    if ($conn->connect_error) {
        die("Database Connection failed: " . $conn->connect_error);
    }
    
    
    $vibrationValues = $_GET['vibrationValue']; 
	
	$query ="SELECT * from status";					// Select all data in table "status"
	$result = $conn->query($query);
	
		while($row = $result->fetch_assoc()) 
		{
			echo $row["status"].$row["L2_status"];					// Echo data , equivalent with send data to esp
			
			    
			 //POST current date and time
                date_default_timezone_set('Asia/Kolkata');
                $d = date("Y-m-d");
                $t = date("H:i:s");
            
              
                if(isset($_GET['isconnect'])){
                    $queryIn = "UPDATE `connect_status` SET `connectStatus`=1 WHERE 1";
                	$resultIn = $conn->query($queryIn);
                }
              
              
              
                if(isset($_GET['Temperature']) && isset($_GET['Humidity']))
                {
              		
                	$sensorData1 = $_GET['Temperature'] ;
                    $sensorData2 = $_GET['Humidity'] ;
                    $lock_id = $_GET['LockId'] ;
                    
            		$query ="SELECT COUNT(Temperature) from $lock_id where Temperature=  '".$sensorData1."'" ;	
            	
            		$result = $conn->query($query);
            	
            		$count = mysqli_fetch_assoc($result);
            		
            	
            		if($count["COUNT(Temperature)"] == 0){
            			
            			  $sql = "INSERT INTO $lock_id (Temperature, Humidity, Vibration) VALUES ('".$sensorData1."', '".$sensorData2."', '".$vibrationValues."')";
            			if ($conn->query($sql) === TRUE) {
                    //    echo "1";
                      } 
            		else {
                        echo "Error: " . $sql . "<br>" . $conn->error;
                      }
            		
	    	    }
	    	    
	    	    
	    	    	if($vibrationValues >= 25000){
			    
			         $sql = "INSERT INTO `casualty`(`lock_id`, `issue`, `solved`, `flag`) VALUES ('".$lock_id."', '400', '1', '1')";
			    
            		if ($conn->query($sql) === TRUE) {
                        //    echo "1";
                      } 
            		else {
                        echo "Error: " . $sql . "<br>" . $conn->error;
                      }
			    
			}  
			
			if($sensorData1 >= 40){
			    
			         $sql = "INSERT INTO `casualty`(`lock_id`, `issue`, `solved`, `flag`) VALUES ('".$lock_id."', '100', '1', '1')";
			    
            		if ($conn->query($sql) === TRUE) {
                        //    echo "1";
                      } 
            		else {
                        echo "Error: " . $sql . "<br>" . $conn->error;
                      }
			    
			}  
				if($sensorData2 >= 85){
			    
			         $sql = "INSERT INTO `casualty`(`lock_id`, `issue`, `solved`, `flag`) VALUES ('".$lock_id."', '300', '1', '1')";
			    
            		if ($conn->query($sql) === TRUE) {
                        //    echo "1";
                      } 
            		else {
                        echo "Error: " . $sql . "<br>" . $conn->error;
                      }
			    
			}  
			
	    	    
           }
			
    }

?>