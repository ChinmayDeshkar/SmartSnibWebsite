<?php

 $servername = "localhost";	// Change this to correspond with your database port
    $username 	= "id17317334_admin";			// Change if use webhost online
    $password 	= "Chinmay@1234";
    $dbname 	= "id17317334_smartsnib";

    // Create connection
    $conn = new mysqli($servername, $username, $password, $dbname);
    // Check connection
    if ($conn->connect_error) {
        die("Database Connection failed: " . $conn->connect_error);
    }
	
	$query = "SELECT * from connect_status";					// Select all data in table "status"
	$result = $conn->query($query);
	
    while($row = $result->fetch_assoc()){
			echo $row['connectStatus'];
			
			if($row['connectStatus'] == 1){
			    	$queryIn = "UPDATE `connect_status` SET `connectStatus`= 0 WHERE 1"; // Select all data in table "status"
                	$resultIn = $conn->query($queryIn);
			}
			if($row['connectStatus'] == 0){
			    	$queryOt = "INSERT INTO `casualty`(`lock_id`, `issue`, `solved`, `flag`) VALUES ('l2a42',500,1,1)"; // Select all data in table "status"
                	$resultOt = $conn->query($queryOt);
			}
			
    }

?>