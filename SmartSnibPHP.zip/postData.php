<?php
//Creates new record as per request
    //Connect to database
$server 	= "localhost";	// Change this to correspond with your database port
$username 	= "id17273598_admin";			// Change if use webhost online
$password 	= "Chinmay@1234";
$DB 		= "id17273598_smartsnib";


    // Create connection
    $conn = new mysqli($server, $username, $password, $DB);
    // Check connection
    if ($conn->connect_error) {
        die("Database Connection failed: " . $conn->connect_error);
    }


    //POST current date and time
    date_default_timezone_set('Asia/Kolkata');
    $d = date("Y-m-d");
    $t = date("H:i:s");


    if(isset($_POST['Temperature']) && isset($_POST['Humidity']))
    {
		
		  $sensorData1 = $_POST['Temperature'];
        $sensorData2 = $_POST['Humidity'];
		$query ="SELECT COUNT(Temperature) from temp_hum where Temperature=  '".$sensorData1."'" ;	
	
		$result = $conn->query($query);
	
		$count = mysqli_fetch_assoc($result);
		
	
		if($count["COUNT(Temperature)"] == 0){
			
			  $sql = "INSERT INTO temp_hum (Temperature, Humidity) VALUES ('".$sensorData1."', '".$sensorData2."')";
			if ($conn->query($sql) === TRUE) {
            echo "OK";
          } 
		else {
            echo "Error: " . $sql . "<br>" . $conn->error;
          }
		
		}
		else{
			print($query) ;
			echo "\n The Count of".$sensorData1." = ".$count["COUNT(Temperature)"] ;
		  
		}
		
		
		
    }

    $conn->close();
?>