<?php

    $conn = mysqli_connect("localhost", "id17317334_admin", "Chinmay@1234", "id17317334_smartsnib");
    // $conn = mysqli_connect("localhost", "root", "", "smartysnib");
    if (!$conn) {
        echo "connection failed";
    }
 
 // Getting the received JSON into $json variable.
 $json = file_get_contents('php://input');
 
 // Decoding the received JSON and store into $obj variable.
 $obj = json_decode($json,true);
//  
 // Getting User email from JSON $obj array and store into $email.
 $query = $obj['query'];
//  $query = "SELECT * FROM `logs` INNER JOIN `lock_info` WHERE `logs`.`Lock_ID` = `lock_info`.`Lock_ID` AND access_id = 'ae001' ORDER BY `logs`.`TimeStamp` DESC";
$result = mysqli_query($conn,$query);

$data = array();
 // Executing SQL Query.

 while($check = mysqli_fetch_assoc($result)){
     array_push($data,$check);
 }

 echo json_encode($data);
    
?>